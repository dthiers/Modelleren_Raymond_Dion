﻿using Goudkoorts.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Goudkoorts.Process {
    class Program {
        static void Main(string[] args) {
            Con_Application ca = new Con_Application(); // <===== deze regelt voor de rest alles.
            Console.Read();
        }
    }
}
