﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Goudkoorts.Domain {
    public class Cart {
        public Boolean IsFull { get; set; }
        public Boolean HasMoved { get; set; }
    }
}
